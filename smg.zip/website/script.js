// function sendMail() {
//     var params = {
//         from_name : document.getElementById("fullname").value,
//         email_id : document.getElementById("email_id").value,
//         message : document.getElementById("message").value
//     }
//     emailjs.send("service_xy4ae5f", "template_iwxvsqp", params).then(function (res) {
//         alert("success!" + res.status);
//     })
// }
